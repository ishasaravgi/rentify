// Add your JavaScript logic here
// Sample property data (replace with your actual data)
const properties = [
    { title: "Property 1", description: "Description of Property 1", price: "$1000", bedrooms: 3, bathrooms: 2, location: "City A" },
    { title: "Property 2", description: "Description of Property 2", price: "$1500", bedrooms: 4, bathrooms: 3, location: "City B" },
    { title: "Property 3", description: "Description of Property 3", price: "$1200", bedrooms: 2, bathrooms: 1, location: "City C" }
  ];
  
  document.addEventListener('DOMContentLoaded', function() {
    const homeBtn = document.getElementById('homeBtn');
    const propertiesBtn = document.getElementById('propertiesBtn');
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
  
    homeBtn.addEventListener('click', function() {
      alert('Home button clicked');
    });
  
    propertiesBtn.addEventListener('click', function() {
      displayProperties();
    });
  
    loginBtn.addEventListener('click', function() {
        window.location.href = 'login.html'; // Redirect to login page
      });
  
    registerBtn.addEventListener('click', function() {
      alert('Register button clicked');
    });
  });
  

  function displayProperties() {
    const propertyList = document.getElementById('propertyList');
    propertyList.innerHTML = ''; // Clear previous property items
  
    properties.forEach(function(property) {
      const propertyItem = document.createElement('div');
      propertyItem.classList.add('propertyItem');
      propertyItem.innerHTML = `
        <h3>${property.title}</h3>
        <p>Description: ${property.description}</p>
        <p>Price: ${property.price}</p>
        <p>Bedrooms: ${property.bedrooms}</p>
        <p>Bathrooms: ${property.bathrooms}</p>
        <p>Location: ${property.location}</p>
      `;
      propertyList.appendChild(propertyItem);
    });
  }

  function displayLogin()
  {
    const loginView = document.getElementById('loginView');
  }
  
// Add your JavaScript logic here
document.addEventListener('DOMContentLoaded', function() {
    const loginFormToggle = document.getElementById('loginFormToggle');
    // const registerFormToggle = document.getElementById('registerFormToggle');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
  
    // Initially hide the register form
    registerForm.style.display = 'none';
  
    // Add event listeners to toggle forms
    loginFormToggle.addEventListener('change', function() {
      if (this.checked) {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
      }
    });
  
    registerFormToggle.addEventListener('change', function() {
      if (this.checked) {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
      }
    });
  });
    